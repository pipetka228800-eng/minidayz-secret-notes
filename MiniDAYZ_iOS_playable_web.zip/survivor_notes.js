(function () {
  "use strict";
  var notes = [
    ["Записка №1 — Старый бункер",
     "Военные отступали к укреплённому объекту. Ищи бетонные сооружения и военные постройки на окраинах населённых пунктов.",
     "Подсказка: проверяй военные зоны и неприметные бетонные здания."],
    ["Записка №2 — Тайник связиста",
     "Связист оставил припасы неподалёку от места, где можно передать сигнал. Ищи вышки, радиомачты и небольшие технические постройки.",
     "Подсказка: ориентир — радиовышки и технические сооружения."],
    ["Записка №3 — Подземный вход",
     "На старой карте был отмечен вход под землю. Ищи лестницы, люки и укреплённые входы возле промышленных объектов.",
     "Подсказка: осматривай промышленные территории и места с люками."],
    ["Записка №4 — Секретный склад",
     "Последний груз спрятали вдали от главной дороги. Следы ведут к заброшенным зданиям и ограждённым площадкам.",
     "Подсказка: исследуй заброшенные объекты за пределами основных дорог."]
  ];

  function initJournal() {
    if (!document.body || document.getElementById("mdz-journal-button")) return;
    var css = document.createElement("style");
    css.textContent = `
      #mdz-journal-button{position:fixed;z-index:99998;right:10px;top:10px;padding:9px 12px;border:1px solid #b9a77c;border-radius:5px;background:rgba(28,31,27,.94);color:#f1e7c9;font:bold 13px Arial,sans-serif;box-shadow:0 2px 8px #000;cursor:pointer;touch-action:manipulation}
      #mdz-journal-overlay{position:fixed;inset:0;z-index:99999;display:none;align-items:center;justify-content:center;background:rgba(0,0,0,.82);font-family:Arial,sans-serif;color:#e9e2ce;padding:12px;box-sizing:border-box}
      #mdz-journal-panel{width:min(520px,94vw);max-height:84vh;overflow:auto;background:#242820;border:2px solid #8f8669;border-radius:7px;box-shadow:0 8px 30px #000;padding:16px;box-sizing:border-box}
      #mdz-journal-panel h2{margin:0 0 6px;font-size:20px;color:#e7d7a8}
      #mdz-journal-panel .sub{font-size:12px;color:#aaa58f;margin-bottom:12px}
      .mdz-note{border:1px solid #5e624f;background:#30362c;margin:8px 0;padding:11px;border-radius:4px}
      .mdz-note h3{margin:0 0 7px;font-size:15px;color:#e8d9ae}
      .mdz-note p{margin:0 0 7px;font-size:13px;line-height:1.45}
      .mdz-note small{color:#c4b98f;font-size:12px}
      #mdz-journal-close{display:block;margin:12px 0 0 auto;padding:10px 18px;background:#77704e;border:1px solid #c0b58c;border-radius:4px;color:white;font-weight:bold;cursor:pointer;touch-action:manipulation}
    `;
    document.head.appendChild(css);

    var btn = document.createElement("button");
    btn.id = "mdz-journal-button";
    btn.type = "button";
    btn.textContent = "📓 ЗАМЕТКИ";
    var overlay = document.createElement("div");
    overlay.id = "mdz-journal-overlay";
    var panel = document.createElement("div");
    panel.id = "mdz-journal-panel";
    var title = document.createElement("h2");
    title.textContent = "Дневник выжившего";
    var sub = document.createElement("div");
    sub.className = "sub";
    sub.textContent = "Начальные записи персонажа";
    panel.appendChild(title);
    panel.appendChild(sub);
    notes.forEach(function (n) {
      var section = document.createElement("section");
      section.className = "mdz-note";
      var h = document.createElement("h3"); h.textContent = n[0];
      var p = document.createElement("p"); p.textContent = n[1];
      var small = document.createElement("small"); small.textContent = n[2];
      section.appendChild(h); section.appendChild(p); section.appendChild(small);
      panel.appendChild(section);
    });
    var close = document.createElement("button");
    close.id = "mdz-journal-close"; close.type = "button"; close.textContent = "ЗАКРЫТЬ";
    panel.appendChild(close); overlay.appendChild(panel);
    document.body.appendChild(btn); document.body.appendChild(overlay);

    function open() { overlay.style.display = "flex"; }
    function shut() { overlay.style.display = "none"; }
    btn.addEventListener("click", open);
    close.addEventListener("click", shut);
    overlay.addEventListener("click", function (e) { if (e.target === overlay) shut(); });
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", initJournal);
  } else {
    initJournal();
  }
}());
