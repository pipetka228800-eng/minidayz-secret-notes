# Mini DAYZ Plus — iOS browser build with notes

This is a static browser build. Upload the **contents** of this folder to a static web host (for example GitHub Pages or Netlify Drop), then open the published HTTPS URL in Safari on iPhone.

- The game itself is the supplied Mini DAYZ Plus 1.2 browser export.
- The 📓 ЗАМЕТКИ button opens four starter clue notes.
- This is a browser overlay, not yet a true inventory item or an actual bunker-door unlock mechanic.
- Keep the published site URL unchanged and avoid clearing Safari website data if you want to preserve the game's browser save data.

For iPhone: open the HTTPS game link in Safari, rotate to landscape, then Share → Add to Home Screen.
